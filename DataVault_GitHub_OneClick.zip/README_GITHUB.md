# DataVault — One-Click GitHub APK Build

1. Create a GitHub repository.
2. Upload all files/folders from this project.
3. Open the repository's Actions tab.
4. Select **Build DataVault APK**.
5. Tap **Run workflow**.
6. Wait for the workflow to finish.
7. Open the completed run.
8. Under **Artifacts**, download **DataVault-debug-apk**.
9. Extract it and install `app-debug.apk` on Android.

The app supports Burmese Unicode text and UTF-8 CSV import/export.
