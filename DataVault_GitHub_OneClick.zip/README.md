# DataVault

A small offline Android app for saving, searching, importing and exporting records.

Fields:
- ID
- Name
- Price
- Notes

Features:
- Burmese/Unicode and English text input
- Local storage
- Instant search across all fields
- Add/edit/delete
- Copy record
- CSV import with quoted-comma support
- UTF-8 CSV export
- Duplicate ID detection during import

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on your Android phone.

Long-press a record to delete it.
